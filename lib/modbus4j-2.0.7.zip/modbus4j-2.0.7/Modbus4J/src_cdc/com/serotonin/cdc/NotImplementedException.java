/*
    Copyright (C) 2006-2007 Serotonin Software Technologies Inc.
 	@author Matthew Lohbihler
 */
package com.serotonin.cdc;

/**
 * @author Matthew Lohbihler
 */
public class NotImplementedException extends RuntimeException {
    static final long serialVersionUID = -1;
    
    public NotImplementedException() {
        super();
    }
}
