package com.serotonin.cdc.messaging;

public interface MessagingExceptionHandler {
    public void receivedException(Exception e);
}
