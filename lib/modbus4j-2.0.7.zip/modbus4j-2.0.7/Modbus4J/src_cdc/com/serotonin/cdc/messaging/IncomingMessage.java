package com.serotonin.cdc.messaging;

public interface IncomingMessage {
    // A marker interface
}
