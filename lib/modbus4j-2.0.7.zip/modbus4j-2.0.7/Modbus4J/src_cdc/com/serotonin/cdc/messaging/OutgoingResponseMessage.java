package com.serotonin.cdc.messaging;

public interface OutgoingResponseMessage extends OutgoingMessage {
    // A marker interface.
}
