package com.serotonin.cdc.messaging;

public interface IncomingRequestMessage extends IncomingMessage {
    // A marker interface.
}
