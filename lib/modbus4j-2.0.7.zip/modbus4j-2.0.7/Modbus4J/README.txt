Build Via the Ant Targets, maven will automatically download and install libraries from web and modbus4j-maven-local repository included in project.

modbus4J.jar requires: (See pom.xml)

A discussion forum for this package can be found at http://mango.serotoninsoftware.com/forum/forums/show/11.page. 